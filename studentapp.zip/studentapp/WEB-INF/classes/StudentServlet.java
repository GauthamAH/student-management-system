import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class StudentServlet extends HttpServlet {

    String url = "jdbc:mysql://"
        + System.getenv("MYSQLHOST") + ":"
        + System.getenv("MYSQLPORT") + "/"
        + System.getenv("MYSQLDATABASE")
        + "?useSSL=false&allowPublicKeyRetrieval=true";

String user = System.getenv("MYSQLUSER");
String pass = System.getenv("MYSQLPASSWORD");


    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);

            /* ================== EXPORT ================== */
            if ("export".equals(action)) {
                res.setContentType("application/vnd.ms-excel");
                res.setHeader("Content-Disposition", "attachment; filename=students.xls");

                PrintWriter out = res.getWriter();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("SELECT * FROM students");

                out.println("ID\tName\tAge\tCourse");

                while (rs.next()) {
                    out.println(
                        rs.getInt("id") + "\t" +
                        rs.getString("name") + "\t" +
                        rs.getInt("age") + "\t" +
                        rs.getString("course")
                    );
                }

                con.close();
                return; // stop further processing
            }

            /* ================== ADD ================== */
            if ("add".equals(action)) {
                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO students VALUES (?,?,?,?)");
                ps.setInt(1, Integer.parseInt(req.getParameter("id")));
                ps.setString(2, req.getParameter("name"));
                ps.setInt(3, Integer.parseInt(req.getParameter("age")));
                ps.setString(4, req.getParameter("course"));
                ps.executeUpdate();
            }

            /* ================== UPDATE ================== */
            if ("update".equals(action)) {
                PreparedStatement ps = con.prepareStatement(
                    "UPDATE students SET name=?, age=?, course=? WHERE id=?");
                ps.setString(1, req.getParameter("name"));
                ps.setInt(2, Integer.parseInt(req.getParameter("age")));
                ps.setString(3, req.getParameter("course"));
                ps.setInt(4, Integer.parseInt(req.getParameter("id")));
                ps.executeUpdate();
            }

            /* ================== DELETE ================== */
            if ("delete".equals(action)) {
                PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM students WHERE id=?");
                ps.setInt(1, Integer.parseInt(req.getParameter("id")));
                ps.executeUpdate();
            }

            /* ================== SEARCH / VIEW ================== */
            ResultSet rs;

            if ("search".equals(action)) {
                String type = req.getParameter("searchType");
                String value = req.getParameter("searchValue");

                String sql = "";

                if (type.equals("id")) sql = "SELECT * FROM students WHERE id=?";
                if (type.equals("age")) sql = "SELECT * FROM students WHERE age=?";
                if (type.equals("name")) sql = "SELECT * FROM students WHERE name LIKE ?";
                if (type.equals("course")) sql = "SELECT * FROM students WHERE course LIKE ?";

                PreparedStatement ps = con.prepareStatement(sql);

                if (type.equals("id") || type.equals("age")) {
                    ps.setInt(1, Integer.parseInt(value));
                } else {
                    ps.setString(1, "%" + value + "%");
                }

                rs = ps.executeQuery();
            }
            else {
                Statement st = con.createStatement();
                rs = st.executeQuery("SELECT * FROM students");
            }

            req.setAttribute("data", rs);
            RequestDispatcher rd = req.getRequestDispatcher("dashboard.jsp");
            rd.forward(req, res);

            con.close();

        } catch (Exception e) {
            res.getWriter().println(e);
        }
    }
}
