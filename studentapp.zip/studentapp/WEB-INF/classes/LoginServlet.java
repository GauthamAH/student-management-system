import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {

    String url = "jdbc:mysql://"
            + System.getenv("MYSQLHOST") + ":"
            + System.getenv("MYSQLPORT") + "/"
            + System.getenv("MYSQLDATABASE")
            + "?useSSL=false&allowPublicKeyRetrieval=true";

    String user = System.getenv("MYSQLUSER");
    String pass = System.getenv("MYSQLPASSWORD");

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);

            String sql = "SELECT * FROM users WHERE username=? AND password_hash=SHA2(?,256)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("user", username);
                response.sendRedirect("dashboard.jsp");
            } else {
                response.getWriter().println("Invalid Login");
            }

            con.close();

        } catch (Exception e) {
            response.getWriter().println("DB Error: " + e);
        }
    }
}
